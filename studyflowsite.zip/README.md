# StudyFlow
StudyFlow is an all-in-one organizer built for IB students. It brings your assignments, IAs, Extended Essay, CAS, and TOK deadlines into one clean app, with a smart dashboard that shows what's due next, an AI-powered study planner, calendars, and progress tracking, so nothing slips through the cracks.

## The website

This repository contains the StudyFlow marketing site — a static, dependency-free
page that presents the product and lets visitors try a working slice of the dashboard.

| File | Purpose |
| --- | --- |
| `index.html` | Page markup and content |
| `styles.css` | All styling, design tokens, light/dark themes, responsive rules |
| `app.js` | Theme toggle, mobile nav, scroll reveals, stat counters, interactive demo, form validation |

### Running it

There's no build step. Open `index.html` directly, or serve the folder:

```bash
npx http-server -p 8080
# then visit http://127.0.0.1:8080
```

### What's on the page

- **Hero** — the core pitch, with a dashboard mockup
- **Built for IB** — the five DP requirements StudyFlow tracks (assignments, IAs, EE, CAS, TOK)
- **Features** — smart dashboard, AI study planner, calendars, progress tracking
- **How it works** — the three-step setup
- **Live demo** — an interactive deadline queue you can filter and tick off, with a workload
  summary that updates as you go
- **FAQ** and a closing call to action

### Notes

- **No external requests.** No CDNs, web fonts, or trackers — the page renders offline.
- **Light and dark themes.** Follows the system preference on first visit and remembers a
  manual choice in `localStorage`.
- **Degrades without JavaScript.** Scroll-reveal animations are scoped to a `.js` class set
  before first paint, so all content stays visible if the script fails to load.
- **Responsive** from 390px up, with no horizontal overflow at any width.
- Respects `prefers-reduced-motion`.
- The signup form is a front-end demo — it validates input but does not submit anywhere.
